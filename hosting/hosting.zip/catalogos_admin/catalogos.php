<?php
declare(strict_types=1);

require __DIR__ . '/_bootstrap.php';
admin_require_login();

$statement = db()->query('SELECT * FROM catalogs ORDER BY created_at DESC LIMIT 200');
$catalogs = $statement->fetchAll();

admin_header('Catalogos');
?>
<div class="card">
    <h1>Catalogos publicados</h1>
    <table>
        <thead>
            <tr>
                <th>Slug</th>
                <th>Titulo</th>
                <th>Estado</th>
                <th>Vendedor</th>
                <th>Cliente</th>
                <th>Vence</th>
                <th>Links</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($catalogs as $catalog): ?>
            <?php $status = resolve_catalog_status($catalog); ?>
            <tr>
                <td><?= htmlspecialchars($catalog['slug'], ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars($catalog['title'], ENT_QUOTES, 'UTF-8') ?></td>
                <td>
                    <span class="badge <?= $status === 'active' ? 'badge--active' : 'badge--expired' ?>">
                        <?= htmlspecialchars($status, ENT_QUOTES, 'UTF-8') ?>
                    </span>
                </td>
                <td><?= htmlspecialchars((string) $catalog['seller_name'], ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars((string) $catalog['client_name'], ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars((string) $catalog['expires_at'], ENT_QUOTES, 'UTF-8') ?></td>
                <td>
                    <?php if (!empty($catalog['public_url'])): ?>
                        <a href="<?= htmlspecialchars($catalog['public_url'], ENT_QUOTES, 'UTF-8') ?>" target="_blank">Ver</a>
                    <?php endif; ?>
                    <?php if (!empty($catalog['pdf_url'])): ?>
                        <br><a href="<?= htmlspecialchars($catalog['pdf_url'], ENT_QUOTES, 'UTF-8') ?>" target="_blank">PDF</a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php admin_footer(); ?>
